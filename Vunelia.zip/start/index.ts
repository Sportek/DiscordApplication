import { Ignitor } from "@sportek/core-next-sportek";

const ignitor = new Ignitor()
ignitor.createFactory()
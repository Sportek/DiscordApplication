import test from 'ava'

test('foo', (t) => {
  t.pass()
})